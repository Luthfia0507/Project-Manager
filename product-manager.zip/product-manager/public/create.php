<?php
session_start();
require_once '../config/db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Normalisasi & Validasi Server-Side (Slide 5)
    $name     = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? 'Umum');
    $price    = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $stock    = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT);

    if (mb_strlen($name) < 3) {
        $errors[] = "Nama produk minimal 3 karakter.";
    }
    if ($price === false || $price <= 0) {
        $errors[] = "Harga harus bernilai lebih dari 0.";
    }
    if ($stock === false || $stock < 0) {
        $errors[] = "Stok tidak boleh negatif.";
    }

    // Jika validasi lolos, jalankan Insert (Slide 6 & 8)
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, category, price, stock) VALUES (:name, :category, :price, :stock)");
            $stmt->execute([
                'name'     => $name,
                'category' => $category,
                'price'    => $price,
                'stock'    => $stock
            ]);

            // Pola Post-Redirect-Get (PRG) (Slide 6)
            header("Location: index.php?status=created");
            exit;
        } catch (PDOException $e) {
            $errors[] = "Gagal menyimpan (mungkin nama produk sudah ada).";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h2>Tambah Produk Baru</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="alert">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8'); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Form HTML (Slide 4) -->
    <form action="create.php" method="POST">
        <div class="form-group">
            <label>Nama Produk</label>
            <input type="text" name="name" minlength="3" required value="<?= htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="form-group">
            <label>Kategori</label>
            <input type="text" name="category" value="<?= htmlspecialchars($_POST['category'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="form-group">
            <label>Harga</label>
            <input type="number" name="price" min="1" step="any" required value="<?= htmlspecialchars($_POST['price'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="form-group">
            <label>Stok</label>
            <input type="number" name="stock" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <button type="submit" class="btn">Simpan Produk</button>
        <a href="index.php" class="btn btn-warning">Batal</a>
    </form>
</div>
</body>
</html>