<?php
session_start();
require_once '../config/db.php';

// Generate Token CSRF untuk aksi hapus (Slide 12)
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

// READ Data Produk (Slide 10)
$stmt = $pdo->query("SELECT id, name, category, price, stock FROM products ORDER BY id DESC");
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Product Manager</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <header>
        <h1>Daftar Produk</h1>
        <a href="create.php" class="btn">+ Tambah Produk</a>
    </header>

    <?php if (isset($_GET['status']) && $_GET['status'] == 'created'): ?>
        <div class="alert alert-success">Produk berhasil disimpan!</div>
    <?php elseif (isset($_GET['status']) && $_GET['status'] == 'deleted'): ?>
        <div class="alert alert-success">Produk berhasil dihapus!</div>
    <?php endif; ?>

    <div class="products">
        <?php foreach ($products as $p): ?>
            <div class="card">
                <!-- Keamanan Output / Cegah XSS (Slide 9) -->
                <h3><?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
                <p>Kategori: <?= htmlspecialchars($p['category'], ENT_QUOTES, 'UTF-8'); ?></p>
                <p>Harga: Rp <?= number_format($p['price'], 0, ',', '.'); ?></p>
                <p>Stok: <?= (int)$p['stock']; ?></p>
                
                <div class="card-actions">
                    <a href="edit.php?id=<?= $p['id']; ?>" class="btn btn-warning">Edit</a>
                    
                    <!-- Form Hapus dengan CSRF (Slide 11 & 12) -->
                    <form method="POST" action="delete.php" onsubmit="return confirm('Yakin hapus?');">
                        <input type="hidden" name="id" value="<?= $p['id']; ?>">
                        <input type="hidden" name="csrf" value="<?= $_SESSION['csrf']; ?>">
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>