<?php
session_start();
require_once '../config/db.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();

if (!$product) {
    die("Produk tidak ditemukan.");
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? 'Umum');
    $price    = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $stock    = filter_input(INPUT_POST, 'stock', FILTER_VALIDATE_INT);

    if (mb_strlen($name) < 3) {
        $errors[] = "Nama produk minimal 3 karakter.";
    }
    if ($price === false || $price <= 0) {
        $errors[] = "Harga harus bernilai lebih dari 0.";
    }
    if ($stock === false || $stock < 0) {
        $errors[] = "Stok tidak boleh negatif.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("UPDATE products SET name = :name, category = :category, price = :price, stock = :stock WHERE id = :id");
        $stmt->execute([
            'name'     => $name,
            'category' => $category,
            'price'    => $price,
            'stock'    => $stock,
            'id'       => $id
        ]);
        header("Location: index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h2>Edit Produk</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8'); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="edit.php?id=<?= $id; ?>" method="POST">
        <div class="form-group">
            <label>Nama Produk</label>
            <input type="text" name="name" minlength="3" required value="<?= htmlspecialchars($_POST['name'] ?? $product['name'], ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="form-group">
            <label>Kategori</label>
            <input type="text" name="category" value="<?= htmlspecialchars($_POST['category'] ?? $product['category'], ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="form-group">
            <label>Harga</label>
            <input type="number" name="price" min="1" step="any" required value="<?= htmlspecialchars($_POST['price'] ?? $product['price'], ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="form-group">
            <label>Stok</label>
            <input type="number" name="stock" min="0" required value="<?= htmlspecialchars($_POST['stock'] ?? $product['stock'], ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <button type="submit" class="btn">Update Produk</button>
        <a href="index.php" class="btn btn-warning">Batal</a>
    </form>
</div>
</body>
</html>